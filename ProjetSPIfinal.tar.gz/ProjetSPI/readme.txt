Yuke TANG 
http://info.univ-lemans.fr/~spi2228/ProjetSPI/ludotheque.html